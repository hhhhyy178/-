module.exports=[97593,a=>{a.v(b=>Promise.all(["server/chunks/ssr/lib_browser-store_ts_1s_kl7uqijkls._.js"].map(b=>a.l(b))).then(()=>b(95528)))}];

//# sourceMappingURL=lib_browser-store_ts_015_wxbcy1z2n._.js.map