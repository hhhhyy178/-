module.exports=[51556,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tutor_route_actions_1xofmqpl9gjhu.js.map