globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/unfiPzcxEqEc7b42hgR4q/_buildManifest.js",
    "static/unfiPzcxEqEc7b42hgR4q/_ssgManifest.js",
    "static/unfiPzcxEqEc7b42hgR4q/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3cfn99dbrcvvp.js",
    "static/chunks/0r-yur70-ku2o.js",
    "static/chunks/3wbm-994r45kr.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/3cfn99dbrcvvp.js",
        "static/chunks/0r-yur70-ku2o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3cfn99dbrcvvp.js",
        "static/chunks/0r-yur70-ku2o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3cfn99dbrcvvp.js",
        "static/chunks/0r-yur70-ku2o.js",
        "static/chunks/3wbm-994r45kr.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
