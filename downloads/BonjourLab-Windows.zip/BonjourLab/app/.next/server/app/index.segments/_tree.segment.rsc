:HL["/_next/static/chunks/2xdq1intcfur4.css","style"]
:HC["/",""]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"e_sVCsFuaQrSH63MZe_2r","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
