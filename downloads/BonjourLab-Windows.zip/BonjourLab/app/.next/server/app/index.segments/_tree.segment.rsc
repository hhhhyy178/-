:HL["/_next/static/chunks/35kmdh0r_n4cu.css","style"]
1:[["children",{"s":"__PAGE__","h":160}]]
0:{"b":"KNQsNUD5Xjz8YGo_LtwQD","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
