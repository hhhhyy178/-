:HL["/_next/static/chunks/0_bnh-vdf6ot7.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"6BVw0zzuQetOWhE-aFu7n","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
