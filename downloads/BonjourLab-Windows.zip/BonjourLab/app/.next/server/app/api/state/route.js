var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/state/route.js")
R.c("server/chunks/[root-of-the-server]__1cgwkzaskr6z8._.js")
R.c("server/chunks/_1-nko52x48w6n._.js")
R.c("server/chunks/[root-of-the-server]__20jfcn5pjiy1t._.js")
R.c("server/chunks/lib_1m4w1f0mya_mp._.js")
R.c("server/chunks/_next-internal_server_app_api_state_route_actions_16zr0br9y_k4v.js")
R.m(43119)
module.exports=R.m(43119).exports
