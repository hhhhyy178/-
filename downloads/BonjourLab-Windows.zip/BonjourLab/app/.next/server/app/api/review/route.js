var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/review/route.js")
R.c("server/chunks/[root-of-the-server]__1yxabyv8ovqqe._.js")
R.c("server/chunks/_113x8_-z__aw8._.js")
R.c("server/chunks/[root-of-the-server]__20jfcn5pjiy1t._.js")
R.c("server/chunks/lib_1m4w1f0mya_mp._.js")
R.c("server/chunks/_next-internal_server_app_api_review_route_actions_0tj22ghzau44t.js")
R.m(15622)
module.exports=R.m(15622).exports
