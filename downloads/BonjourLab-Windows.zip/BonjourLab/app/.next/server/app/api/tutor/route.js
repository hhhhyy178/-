var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tutor/route.js")
R.c("server/chunks/[root-of-the-server]__0zxyti3ftszuj._.js")
R.c("server/chunks/_0viyoyu_xtsla._.js")
R.c("server/chunks/lib_1m4w1f0mya_mp._.js")
R.c("server/chunks/[root-of-the-server]__0ujbekifrv0_1._.js")
R.c("server/chunks/_next-internal_server_app_api_tutor_route_actions_1xofmqpl9gjhu.js")
R.m(30317)
module.exports=R.m(30317).exports
