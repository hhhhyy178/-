var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/attempt/route.js")
R.c("server/chunks/[root-of-the-server]__05xm2s5hyp67g._.js")
R.c("server/chunks/_0c7y9rbq2i2iv._.js")
R.c("server/chunks/[root-of-the-server]__20jfcn5pjiy1t._.js")
R.c("server/chunks/lib_1m4w1f0mya_mp._.js")
R.c("server/chunks/_next-internal_server_app_api_attempt_route_actions_0sj9r9k2iz6z2.js")
R.m(20316)
module.exports=R.m(20316).exports
