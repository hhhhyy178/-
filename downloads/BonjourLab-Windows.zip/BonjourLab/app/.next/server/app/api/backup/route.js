var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/backup/route.js")
R.c("server/chunks/[root-of-the-server]__1cew2mj3jqivh._.js")
R.c("server/chunks/_0gxnbupj6kwhc._.js")
R.c("server/chunks/[root-of-the-server]__20jfcn5pjiy1t._.js")
R.c("server/chunks/lib_1m4w1f0mya_mp._.js")
R.c("server/chunks/_next-internal_server_app_api_backup_route_actions_0v-rtcu-20622.js")
R.m(93299)
module.exports=R.m(93299).exports
