var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/session/route.js")
R.c("server/chunks/[root-of-the-server]__08xwnni088nwq._.js")
R.c("server/chunks/[root-of-the-server]__20jfcn5pjiy1t._.js")
R.c("server/chunks/_1i1xpb590f_i-._.js")
R.c("server/chunks/_next-internal_server_app_api_session_route_actions_0eknud3pon_dm.js")
R.m(42814)
module.exports=R.m(42814).exports
