@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "runtime\node.exe" (
 echo 请先完整解压 BonjourLab 文件夹，再双击启动。
 pause
 exit /b 1
)
"runtime\node.exe" "launch.mjs"
if errorlevel 1 (
 echo 启动未完成，请查看上方提示，或把错误信息发给开发者。
 pause
)
